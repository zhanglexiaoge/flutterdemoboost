//
//  ViewController.m
//  iosNtive
//
//  Created by 张乐 on 2020/11/9.
//  Copyright © 2020 张乐. All rights reserved.
//

#import "ViewController.h"

#import <Flutter/Flutter.h>
#import "PlatformRouterImp.h"
#import <flutter_boost/FlutterBoost.h>
#import "AppManager.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    
   
   
    
    UIButton *nativeButton = [UIButton buttonWithType:UIButtonTypeCustom];
       nativeButton.frame = CGRectMake(self.view.frame.size.width * 0.5 - 50, 200, 100, 40);
       nativeButton.backgroundColor = [UIColor redColor];
       [nativeButton setTitle:@"push native" forState:UIControlStateNormal];
       [nativeButton addTarget:self action:@selector(pushNative) forControlEvents:UIControlEventTouchUpInside];
       [self.view addSubview:nativeButton];
       
       UIButton *pushEmbeded = [UIButton buttonWithType:UIButtonTypeCustom];
       pushEmbeded.frame = CGRectMake(self.view.frame.size.width * 0.5 - 70, 150, 140, 40);
       pushEmbeded.backgroundColor = [UIColor redColor];
       [pushEmbeded setTitle:@"push flutter" forState:UIControlStateNormal];
       [pushEmbeded addTarget:self action:@selector(pushEmbeded) forControlEvents:UIControlEventTouchUpInside];
       [self.view addSubview:pushEmbeded];
}



- (void)pushNative
{
//    UINavigationController *nvc = (id)self.window.rootViewController;
//    UIViewControllerDemo *vc = [[UIViewControllerDemo alloc] initWithNibName:@"UIViewControllerDemo" bundle:[NSBundle mainBundle]];
//    [nvc pushViewController:vc animated:YES];
}

- (void)pushEmbeded
{
//    UINavigationController *nvc = (id)self.window.rootViewController;
//    UIViewController *vc = [[NativeViewController alloc] init];
//    [nvc pushViewController:vc animated:YES];
     [[AppManager shareManager] open:@"set_mouble" urlParams:@{@"uid":@"777"} exts:@{@"animated":@(YES)} completion:nil];
    
    
    
}


@end
