//
//  AppManager.m
//  iosNtive
//
//  Created by 张乐 on 2020/11/11.
//  Copyright © 2020 张乐. All rights reserved.
//

#import "AppManager.h"
#import "PlatformRouterImp.h"
#import "JMPFlutterViewController.h"
#import "ViewController.h"

@implementation AppManager

#pragma mark - 单例模式
+ (instancetype)shareManager {
    static AppManager *manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[AppManager alloc] initAppManager];

    });
    return manager;
}

- (instancetype)initAppManager {
    self = [super init];
    if (self) {
//        [self createSqliteTable];
//        [self willResignActiveAction];
    }
    return self;
}


- (void)openLoginVc {
    UIWindow *keyWindow  =  [UIApplication sharedApplication].keyWindow;
    
    ViewController *vc = [[ViewController alloc] init];
//       vc.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"hybrid" image:nil tag:0];
//       UITabBarController *tabVC = [[UITabBarController alloc] init];
       UINavigationController *rvc = [[UINavigationController alloc] initWithRootViewController:vc];
     
      keyWindow.rootViewController = rvc;
     [self configFlutterModule];
}
#pragma mark - Flutter 模块
- (void)configFlutterModule {
    //flutter 调原生
   PlatformRouterImp *router = [PlatformRouterImp new];
     [FlutterBoostPlugin.sharedInstance startFlutterWithPlatform:router
                                                        onStart:^(FlutterEngine *engine) {
        
        // 注册MethodChannel，监听flutter侧的getPlatformVersion调用
        FlutterMethodChannel *flutterMethodChannel = [FlutterMethodChannel methodChannelWithName:@"Flutter_Module_Methodchannel" binaryMessenger:engine.binaryMessenger];
        
        [flutterMethodChannel setMethodCallHandler:^(FlutterMethodCall * _Nonnull call, FlutterResult  _Nonnull result) {
             JMPFlutterViewController *rootVc = (JMPFlutterViewController *)FlutterBoostPlugin.sharedInstance.currentViewController;
            NSString *method = call.method;
            if ([method isEqualToString:@"getPlatformVersion"]) {
                //获取系统版本号
                NSString *sysVersion = [[UIDevice currentDevice] systemVersion];
                result(sysVersion);
            }  else if ([method isEqualToString:@"native_otherPage"]) {
                           NSDictionary *dict = call.arguments;
                
//                           HTUserCacheModel *userModel = [[WCDBManager shared] getUserObjectByUid:[dict[@"userId"] stringValue]];
                          result(@"test");
            }else if ([method isEqualToString:@"webview"]) {
                //webview 打开
                NSDictionary *dict = call.arguments;
//                HTWKWebViewController *webViewVc = [[HTWKWebViewController alloc] initWithUrl:dict[@"url"] title:nil hideRightItem:YES];
//                [rootVc pushViewController:webViewVc animated:YES];
            }else {
              result(FlutterMethodNotImplemented);
            }
            
        }];
    }];

}

#pragma mark - 发送参数到Flutter模块
- (void)sendParamsToFlutterModule {
   NSDictionary *dict = @{ @"baseUrl": @"www.baidu.com", @"token": @"666666", @"deviceUuid": @"ios" };
    [FlutterBoostPlugin.sharedInstance sendEvent:@"Flutter_Module_Eventchannel" arguments:dict];
}

#pragma mark - Flutter push 页面
- (void)open:(NSString *)url urlParams:(NSDictionary *)urlParams exts:(NSDictionary *)exts completion:(void (^)(BOOL))completion {
    [FlutterBoostPlugin open:url urlParams:urlParams exts:exts onPageFinished:^(NSDictionary *dict) {
    } completion:completion];
}

#pragma mark - Flutter present 页面
- (void)present:(NSString *)url urlParams:(NSDictionary *)urlParams exts:(NSDictionary *)exts completion:(void (^)(BOOL))completion {
    [FlutterBoostPlugin present:url urlParams:urlParams exts:exts onPageFinished:^(NSDictionary *dict) {
    } completion:completion];
}

#pragma mark - Flutter 关闭 页面
- (void)close:(NSString *)uid result:(NSDictionary *)result exts:(NSDictionary *)exts completion:(void (^)(BOOL))completion {
    [FlutterBoostPlugin close:uid result:result exts:exts completion:completion];
}





@end
