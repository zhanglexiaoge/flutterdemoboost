//
//  AppManager.h
//  iosNtive
//
//  Created by 张乐 on 2020/11/11.
//  Copyright © 2020 张乐. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface AppManager : NSObject

/**
 单例
 */
+ (instancetype)shareManager;

/**
 发送参数到Flutter模块
 */
- (void)sendParamsToFlutterModule;

- (void)openLoginVc;

- (void)configFlutterModule ;


#pragma mark - Flutter push 页面
- (void)open:(NSString *)url urlParams:(NSDictionary *)urlParams exts:(NSDictionary *)exts completion:(void (^)(BOOL))completion;

#pragma mark - Flutter present 页面
- (void)present:(NSString *)url urlParams:(NSDictionary *)urlParams exts:(NSDictionary *)exts completion:(void (^)(BOOL))completion ;

- (void)close:(NSString *)uid result:(NSDictionary *)result exts:(NSDictionary *)exts completion:(void (^)(BOOL))completion ;


@end

NS_ASSUME_NONNULL_END
