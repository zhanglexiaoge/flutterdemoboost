//
//  DemoRouter.m
//  Runner
//
//  Created by Jidong Chen on 2018/10/22.
//  Copyright © 2018年 The Chromium Authors. All rights reserved.
//

#import "PlatformRouterImp.h"
#import <flutter_boost/FlutterBoost.h>
#import "JMPFlutterViewController.h"

@interface PlatformRouterImp()
@end

@implementation PlatformRouterImp


//name 表示打开 flutter 页面标识 push跳转
- (void)open:(NSString *)name
   urlParams:(NSDictionary *)params
        exts:(NSDictionary *)exts
  completion:(void (^)(BOOL))completion
{
//    if ([name isEqualToString:@"native"]) {//模拟打开native页面
//        [self openNativeVC:name urlParams:params exts:exts];
//        return;
//    }

    BOOL animated = [exts[@"animated"] boolValue];
    JMPFlutterViewController *vc = JMPFlutterViewController.new;
    [vc setName:name params:params];
    UIViewController *resultVC = [self topViewController];
    
    
    [resultVC.navigationController pushViewController:vc animated:animated];
    if(completion) completion(YES);
}

//name 表示打开 flutter 页面标识 present跳转
//params 传入的参数值
- (void)present:(NSString *)name
   urlParams:(NSDictionary *)params
        exts:(NSDictionary *)exts
  completion:(void (^)(BOOL))completion
{
    BOOL animated = [exts[@"animated"] boolValue];
    JMPFlutterViewController *vc = JMPFlutterViewController.new;
    [vc setName:name params:params];
    [[[self topViewController] navigationController] presentViewController:vc animated:animated completion:^{
            if(completion) completion(YES);
     }];
//    [self.navigationController presentViewController:vc animated:animated completion:^{
//        if(completion) completion(YES);
//    }];
}


- (void) close:(NSString *)uid
        result:(NSDictionary *)result
          exts:(NSDictionary *)exts
    completion:(void (^)(BOOL))completion {
    JMPFlutterViewController *vc = (id)[self topViewController];
    if (vc.presentingViewController && (!vc.navigationController.viewControllers || vc.navigationController.viewControllers.count == 1)) {
        [vc dismissViewControllerAnimated:YES completion:^{
            if (completion) {
                completion(YES);
            }
        }];
    } else {
        [vc.navigationController popViewControllerAnimated:YES];
       // [vc popViewControllerAnimated:YES];
        if (completion) {
            completion(YES);
        }
    }
}


- (UIViewController *)topViewController {
    UIViewController *resultVC;
    resultVC = [self _topViewController:[[[[UIApplication sharedApplication] delegate] window] rootViewController]];
    while (resultVC.presentedViewController)
        resultVC = [self _topViewController:resultVC.presentedViewController];
    return resultVC;
}

- (UIViewController *)_topViewController:(UIViewController *)vc {
    if ([vc isKindOfClass:[UINavigationController class]]) {
        return [self _topViewController:[(UINavigationController *)vc topViewController]];
    } else if ([vc isKindOfClass:[UITabBarController class]]) {
        return [self _topViewController:[(UITabBarController *)vc selectedViewController]];
    } else {
        return vc;
    }
    return nil;
}


@end
