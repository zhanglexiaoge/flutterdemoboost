//
//  JMPFlutterViewController.m
//  iosNtive
//
//  Created by 张乐 on 2020/11/11.
//  Copyright © 2020 张乐. All rights reserved.
//

#import "JMPFlutterViewController.h"
#import "AppManager.h"

@interface JMPFlutterViewController ()

@end

@implementation JMPFlutterViewController

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
   
    [[AppManager shareManager] sendParamsToFlutterModule];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
//    self.fd_prefersNavigationBarHidden = YES;
//    self.fd_interactivePopLeftDistance = 55;
}

- (UIView *)splashScreenView {
    return nil;
}


@end
