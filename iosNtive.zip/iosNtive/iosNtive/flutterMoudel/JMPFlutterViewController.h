//
//  JMPFlutterViewController.h
//  iosNtive
//
//  Created by 张乐 on 2020/11/11.
//  Copyright © 2020 张乐. All rights reserved.
//

#import <Flutter/Flutter.h>
#import <flutter_boost/FlutterBoost.h>
NS_ASSUME_NONNULL_BEGIN

@interface JMPFlutterViewController : FLBFlutterViewContainer

@end

NS_ASSUME_NONNULL_END
