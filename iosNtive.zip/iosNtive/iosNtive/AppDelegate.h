//
//  AppDelegate.h
//  iosNtive
//
//  Created by 张乐 on 2020/11/9.
//  Copyright © 2020 张乐. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (nullable, nonatomic, strong) UIWindow *window;

@end

